import 'dart:io';

import 'package:sekaipod/core/navigation/routes.dart';
import 'package:sekaipod/core/providers/filtered_audio_files_provider.dart';
import 'package:sekaipod/core/providers/shared_preferences_with_cache_provider.dart';
import 'package:sekaipod/core/services/audio_player_service.dart';
import 'package:sekaipod/features/music/album/providers/album_details_provider.dart';
import 'package:sekaipod/features/music/artists/providers/artist_names_provider.dart';
import 'package:sekaipod/features/music/genres/providers/genres_provider.dart';
import 'package:sekaipod/features/music/playlist/providers/playlists_provider.dart';
import 'package:sekaipod/features/music/songs/provider/songs_provider.dart';
import 'package:sekaipod/features/settings/controller/settings_preferences_controller.dart';
import 'package:sekaipod/features/tutorial/controller/tutorial_controller.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:permission_handler/permission_handler.dart';

final splashControllerProvider =
    AsyncNotifierProvider<SplashControllerNotifier, void>(
      SplashControllerNotifier.new,
    );

class SplashControllerNotifier extends AsyncNotifier<void> {
  @override
  Future<void> build() async {
    await requestStoragePermissions();
  }

  Future<void> requestStoragePermissions() async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() async {
      final onlineMode = ref.read(settingsPreferencesControllerProvider).fetchOnlineMusic;
      if (!onlineMode && !kIsWeb && (Platform.isAndroid || Platform.isIOS)) {
        final PermissionStatus audioPermission = await Permission.audio.request();
        final PermissionStatus genericStoragePermission = await Permission.storage.request();
        if (audioPermission.isDenied && genericStoragePermission.isDenied) {
          throw const AudioPermissionDeniedException();
        }
        if (audioPermission.isPermanentlyDenied && genericStoragePermission.isPermanentlyDenied) {
          throw const AudioPermissionPermanentlyDeniedException();
        }
      }

      await initializeApp();
    });
  }

  Future<void> initializeApp() async {
    // Load the filtered audio files metadata
    final filteredAudioFilesMetadata = await ref
        .read(filteredAudioFilesProvider.future)
        .then((value) => value.toList());

    // Set the audio source
    await ref
        .read(audioPlayerServiceProvider.notifier)
        .setAudioSource(musicMetadataList: filteredAudioFilesMetadata);

    // Set the initial loop mode
    await ref
        .read(settingsPreferencesControllerProvider.notifier)
        .setInitialRepeatMode();

    // Invalidate the providers that depend on the audio files metadata
    ref.invalidate(albumDetailsProvider);
    ref.invalidate(artistNamesProvider);
    ref.invalidate(songsProvider);
    ref.invalidate(playlistsProvider);
    ref.invalidate(genresProvider);
    ref.invalidate(tutorialControllerProvider);

    // Load the playlists
    ref.read(playlistsProvider.notifier).refreshProvider();

    final prefs = ref.read(sharedPreferencesWithCacheProvider).requireValue;
    final onboardingComplete = prefs.getBool('sekaipod.onboardingComplete') ?? false;
    ref.read(routerProvider).goNamed(
      onboardingComplete ? Routes.menu.name : Routes.onboarding.name,
    );
  }
}

class AudioPermissionDeniedException implements Exception {
  const AudioPermissionDeniedException();
}

class AudioPermissionPermanentlyDeniedException implements Exception {
  const AudioPermissionPermanentlyDeniedException();
}
