import 'dart:io';

import 'package:sekaipod/core/constants/app_palette.dart';
import 'package:sekaipod/core/constants/assets.dart';
import 'package:sekaipod/core/extensions/build_context_extensions.dart';
import 'package:sekaipod/core/models/music_metadata.dart';
import 'package:sekaipod/features/music/album/models/album_model.dart';
import 'package:sekaipod/features/music/search/model/search_model.dart';
import 'package:flutter/cupertino.dart';

class SearchListTile extends StatelessWidget {
  final SearchResultsModel searchResult;
  final bool isSelected;
  final VoidCallback onTap;
  final VoidCallback onLongPress;

  const SearchListTile({
    super.key,
    required this.searchResult,
    required this.isSelected,
    required this.onTap,
    required this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    final isDarkTheme =
        CupertinoTheme.of(context).brightness == Brightness.dark;
    final borderColor = isDarkTheme
        ? AppPalette.darkListTileBorderColor
        : AppPalette.lightListTileBorderColor;
    final Border? tileBorder = isSelected
        ? null
        : Border(bottom: BorderSide(color: borderColor));

    late final String title;
    late final String description;
    late final String? imageFilePath;
    if (searchResult.searchResultType == SearchResultType.track) {
      final metadata = searchResult.result as MusicMetadata;
      title = metadata.getTrackName;
      description = metadata.getMainArtistName;
    } else if (searchResult.searchResultType == SearchResultType.artist) {
      title = searchResult.result as String;
      description = context.localization.nAlbums(searchResult.count);
    } else if (searchResult.searchResultType == SearchResultType.album) {
      final albumDetails = searchResult.result as AlbumModel;
      title = albumDetails.albumName;
      description = context.localization.nSongs(searchResult.count);
      imageFilePath = albumDetails.albumArtPath;
    } else {
      title = context.localization.searchScreenTitle;
      if (searchResult.count == 0) {
        description = context.localization.searchEmptyText;
      } else {
        description =
            "${context.localization.resultsForText} ${searchResult.result}";
      }
    }

    return GestureDetector(
      onTap: onTap,
      onLongPress: onLongPress,
      child: SizedBox(
        height: 54,
        width: double.infinity,
        child: DecoratedBox(
          decoration: BoxDecoration(
            gradient: isSelected
                ? const LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      AppPalette.selectedTileGradientColor1,
                      AppPalette.selectedTileGradientColor2,
                    ],
                  )
                : null,
            border: tileBorder,
          ),
          child: Row(
            children: [
              (searchResult.searchResultType == SearchResultType.artist ||
                      searchResult.searchResultType ==
                          SearchResultType.defaultSearch)
                  ? SizedBox(
                      height: 54,
                      width: 54,
                      child: ColoredBox(
                        color: AppPalette.defaultIconBackgroundColor,
                        child: Center(
                          child: Icon(
                            (searchResult.searchResultType ==
                                    SearchResultType.artist)
                                ? CupertinoIcons.person_alt
                                : CupertinoIcons.search,
                            size: 40,
                            color: AppPalette.statusBarGradientColor2,
                          ),
                        ),
                      ),
                    )
                  : Image(
                      image:
                          (searchResult.searchResultType ==
                                  SearchResultType.album &&
                              imageFilePath != null)
                          ? (searchResult.result as AlbumModel).isOnDevice()
                                ? FileImage(File(imageFilePath))
                                : NetworkImage(imageFilePath)
                          : const AssetImage(Assets.defaultAlbumCoverImage),
                      errorBuilder: (_, _, _) => Image.asset(
                        Assets.defaultAlbumCoverImage,
                        fit: BoxFit.cover,
                        height: 54,
                        width: 54,
                      ),
                      height: 54,
                      width: 54,
                      fit: BoxFit.cover,
                    ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: CupertinoTheme.of(context).textTheme.textStyle
                          .copyWith(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: isSelected
                                ? context.appInverseTextColor
                                : context.appPrimaryTextColor,
                          ),
                      maxLines: 1,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      description,
                      style: CupertinoTheme.of(context).textTheme.textStyle
                          .copyWith(
                            color: isSelected
                                ? context.appInverseTextColor
                                : context.appSecondaryTextColor,
                          ),
                      maxLines: 1,
                    ),
                  ],
                ),
              ),
              if (isSelected)
                Icon(
                  CupertinoIcons.right_chevron,
                  color: context.appInverseTextColor,
                ),
            ],
          ),
        ),
      ),
    );
  }
}
