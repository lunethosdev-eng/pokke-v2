import 'dart:io';

import 'package:sekaipod/core/constants/app_palette.dart';
import 'package:sekaipod/core/constants/assets.dart';
import 'package:sekaipod/core/extensions/build_context_extensions.dart';
import 'package:sekaipod/core/models/music_metadata.dart';
import 'package:flutter/cupertino.dart';

class PlaylistSongListTile extends StatelessWidget {
  final MusicMetadata songMetadata;
  final bool isSelected;
  final bool isCurrentlyPlaying;
  final VoidCallback onTap;
  final VoidCallback onLongPress;

  const PlaylistSongListTile({
    super.key,
    required this.songMetadata,
    required this.isSelected,
    required this.isCurrentlyPlaying,
    required this.onTap,
    required this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      onLongPress: onLongPress,
      child: SizedBox(
        height: 54,
        width: double.infinity,
        child: DecoratedBox(
          decoration: BoxDecoration(
            gradient: isSelected
                ? const LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      AppPalette.selectedTileGradientColor1,
                      AppPalette.selectedTileGradientColor2,
                    ],
                  )
                : null,
            border: isSelected
                ? null
                : const Border(
                    bottom: BorderSide(
                      color: AppPalette.lightDeviceFrameGradientColor1,
                    ),
                  ),
          ),
          child: Row(
            children: [
              Image(
                image: (songMetadata.thumbnailPath != null)
                    ? (songMetadata.isOnDevice)
                          ? FileImage(File(songMetadata.thumbnailPath!))
                          : NetworkImage(songMetadata.thumbnailPath!)
                    : const AssetImage(Assets.defaultAlbumCoverImage),
                errorBuilder: (_, _, _) => Image.asset(
                  Assets.defaultAlbumCoverImage,
                  fit: BoxFit.fitWidth,
                ),
                height: 54,
                width: 54,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Flexible(
                      child: Text(
                        songMetadata.trackName ??
                            context.localization.unknownSong,
                        style: CupertinoTheme.of(context).textTheme.textStyle
                            .copyWith(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: isSelected
                                  ? context.appInverseTextColor
                                  : context.appPrimaryTextColor,
                            ),
                        maxLines: 1,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Flexible(
                      child: Text(
                        songMetadata.getTrackArtistNames ??
                            context.localization.unknownArtist,
                        style: CupertinoTheme.of(context).textTheme.textStyle
                            .copyWith(
                              color: isSelected
                                  ? context.appInverseTextColor
                                  : context.appSecondaryTextColor,
                            ),
                        maxLines: 1,
                      ),
                    ),
                  ],
                ),
              ),
              if (isCurrentlyPlaying)
                Icon(
                  CupertinoIcons.volume_up,
                  size: 18,
                  color: isSelected
                      ? context.appInverseTextColor
                      : context.appPrimaryTextColor,
                ),
              if (!isCurrentlyPlaying && isSelected)
                Icon(
                  CupertinoIcons.right_chevron,
                  color: context.appInverseTextColor,
                ),
            ],
          ),
        ),
      ),
    );
  }
}
