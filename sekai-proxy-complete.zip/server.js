import express from "express";
import cors from "cors";
import { createServer } from "http";
import { fileURLToPath } from "url";
import { dirname, join } from "path";

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();
const server = createServer(app);
const PORT = process.env.PORT || 3000;

// CORS so Netlify / Sekai OS can call this server
app.use(cors({
  origin: "*",
  methods: ["GET", "POST", "OPTIONS", "PUT", "DELETE"],
  allowedHeaders: ["*"]
}));

// HEALTH CHECK - use this URL in UptimeRobot every 5 minutes
app.get("/health", (req, res) => {
  res.status(200).json({
    status: "ok",
    service: "Sekai Proxy",
    engines: ["scramjet", "ultraviolet"],
    uptime: Math.floor(process.uptime()),
    time: new Date().toISOString()
  });
});

// Minimal root page (no full browser UI)
app.get("/", (req, res) => {
  res.type("html").send(`<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sekai Proxy</title>
  <style>
    * { box-sizing: border-box; }
    body { font-family: system-ui, -apple-system, sans-serif; background: #0c1216; color: #e8eef2; min-height: 100vh; display: flex; align-items: center; justify-content: center; margin: 0; padding: 20px; }
    .card { background: #161e24; border-radius: 24px; padding: 36px; max-width: 440px; text-align: center; box-shadow: 0 20px 50px rgba(0,0,0,.4); }
    .status { display: inline-block; background: #10b98122; color: #34d399; padding: 6px 14px; border-radius: 20px; font-size: 13px; margin-bottom: 18px; font-weight: 600; }
    h1 { margin: 0 0 10px; font-size: 24px; font-weight: 700; }
    p { color: #8b969e; font-size: 14px; line-height: 1.55; margin: 0 0 16px; }
    code { background: #0c1216; padding: 3px 8px; border-radius: 8px; font-size: 12px; color: #a5b4c2; }
    .engines { display: flex; gap: 10px; justify-content: center; margin-top: 20px; }
    .engine { background: #0c1216; padding: 10px 16px; border-radius: 12px; font-size: 13px; }
  </style>
</head>
<body>
  <div class="card">
    <div class="status">● Online</div>
    <h1>Sekai Proxy</h1>
    <p>Backend dual <b>Scramjet + Ultraviolet</b> para Sekai OS.<br>
    Este servidor <b>no</b> tiene interfaz de navegación propia.<br>
    Conéctalo desde el Safari de Sekai OS.</p>
    <p>Health check: <code>/health</code></p>
    <div class="engines">
      <div class="engine">Scramjet</div>
      <div class="engine">Ultraviolet</div>
    </div>
  </div>
</body>
</html>`);
});

// Static assets
app.use("/uv/", express.static(join(__dirname, "public/uv")));
app.use("/scram/", express.static(join(__dirname, "public/scram")));
app.use(express.static(join(__dirname, "public")));

// UV config
app.get("/uv/uv.config.js", (req, res) => {
  res.type("application/javascript").send(`
self.__uv$config = {
  prefix: "/uv/service/",
  bare: "/bare/",
  encodeUrl: Ultraviolet.codec.xor.encode,
  decodeUrl: Ultraviolet.codec.xor.decode,
  handler: "/uv/uv.handler.js",
  client: "/uv/uv.client.js",
  bundle: "/uv/uv.bundle.js",
  config: "/uv/uv.config.js",
  sw: "/uv/uv.sw.js"
};
`);
});

server.listen(PORT, "0.0.0.0", () => {
  console.log("[Sekai Proxy] Running on port " + PORT);
  console.log("[Sekai Proxy] Health → http://localhost:" + PORT + "/health");
  console.log("[Sekai Proxy] Engines: Scramjet + Ultraviolet");
});
