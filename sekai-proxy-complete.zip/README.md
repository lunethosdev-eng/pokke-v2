# Sekai Proxy

Backend dual **Scramjet + Ultraviolet** para Sekai OS.

- Interfaz de Sekai OS → Netlify
- Este proxy → Render (gratis)
- En el Safari de Sekai puedes elegir qué motor usar

## Características

- Endpoint `/health` para keep-alive (UptimeRobot cada 5 min)
- CORS abierto para que Netlify pueda conectarse
- Interfaz mínima (solo status)
- Preparado para Scramjet y Ultraviolet

## Cómo desplegar en Render (sin tarjeta)

1. Crea cuenta en https://render.com (con GitHub)
2. New → Web Service
3. Conecta este repositorio (o sube el código)
4. Configuración:
   - **Name**: sekai-proxy
   - **Runtime**: Node
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Instance Type**: Free
5. Create Web Service

Cuando termine te dará una URL tipo:
`https://sekai-proxy-xxxx.onrender.com`

## Keep-alive (para que no se duerma)

1. Ve a https://uptimerobot.com (gratis, no pide tarjeta)
2. Add New Monitor
3. Monitor Type: **HTTP(s)**
4. URL: `https://TU-URL-DE-RENDER.onrender.com/health`
5. Monitoring Interval: **5 minutes**
6. Create Monitor

Con esto el servidor se mantiene despierto.

## Conectar con Sekai OS

En el Safari de Sekai OS pondremos dos opciones:

- Scramjet → `https://tu-proxy.onrender.com/scram/`
- Ultraviolet → `https://tu-proxy.onrender.com/uv/`

## Estructura

```
sekai-proxy/
├── server.js          ← Servidor principal
├── package.json
├── public/
│   ├── uv/            ← Archivos de Ultraviolet
│   └── scram/         ← Archivos de Scramjet (añadir después del build)
└── README.md
```

## Notas

- Este servidor **no** tiene navegador propio. Solo el backend.
- La interfaz de navegación está en Sekai OS (Netlify).
- Para que Scramjet y UV funcionen al 100% hay que añadir los archivos de cliente compilados en `public/uv` y `public/scram`.

