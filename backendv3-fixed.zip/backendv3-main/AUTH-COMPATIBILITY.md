# Hoshi 2.5 authentication compatibility

Hoshi keeps an isolated server-side session for Prism OS. Upstream `Set-Cookie` values are stored in that session and replayed only when their domain/path/security rules match the next upstream request.

Prism first calls `/api/session`, stores the opaque Hoshi session id locally, and sends it as `X-Hoshi-Session` on proxied API requests. This avoids depending on browser access to upstream cookies across origins.

For login pages rendered through a web-proxy runtime, the upstream site may still enforce browser/device security, CAPTCHA, MFA, or origin checks. Hoshi intentionally does not attempt to defeat those controls.

Set `PROXY_ALLOWLIST` to the domains your deployment is authorized to proxy. Keep `ALLOW_ALL_PROXY=false` on public deployments.
