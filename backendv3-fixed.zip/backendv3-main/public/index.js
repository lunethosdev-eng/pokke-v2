"use strict";

// Elementos Principales y Terminal
const form = document.getElementById("sj-form");
const address = document.getElementById("sj-address");
const searchEngine = document.getElementById("sj-search-engine");
const homeView = document.getElementById("home-view");
const musicView = document.getElementById("music-view");
const iframesContainer = document.getElementById("iframes-container");
const logEl = document.getElementById("term-log");

// Indicadores de Estado (Pills)
const pillApi = document.getElementById("pill-api");
const pillSw = document.getElementById("pill-sw");
const pillTransport = document.getElementById("pill-transport");
const pillScraper = document.getElementById("pill-scraper");

// Botones de Header
const btnMusicToggle = document.getElementById("btn-music-toggle");
const btnCloseMusic = document.getElementById("btn-close-music");
const btnHealth = document.getElementById("btn-health");
const btnClear = document.getElementById("btn-clear");
const btnProxyTest = document.getElementById("btn-proxy-test");

// Sub-Tabs de Música
const tabBtnPlayer = document.getElementById("tab-btn-player");
const tabBtnApi = document.getElementById("tab-btn-api");
const tabContentPlayer = document.getElementById("tab-content-player");
const tabContentApi = document.getElementById("tab-content-api");

// Elementos de Música y Reproductor
const scraperBadge = document.getElementById("scraper-badge");
const scraperDownloadingText = document.getElementById("scraper-downloading-text");
const musicAddForm = document.getElementById("music-add-form");
const musicAddInput = document.getElementById("music-add-input");
const playerCover = document.getElementById("player-cover");
const playerAnimatedCover = document.getElementById("player-animated-cover");
const playerTitle = document.getElementById("player-title");
const playerArtist = document.getElementById("player-artist");
const musicAudioPlayer = document.getElementById("music-audio-player");
const lyricsContainer = document.getElementById("lyrics-container");
const queueList = document.getElementById("queue-list");
const queueCount = document.getElementById("queue-count");
const tracksList = document.getElementById("tracks-list");

// Estado Global de la App
let currentSyncedLyrics = [];
let lastTrackCount = -1;

const SEARCH_ENGINES = {
  google: { name: "Google", url: "https://www.google.com/search?q=%s" },
  ddg: { name: "DuckDuckGo", url: "https://duckduckgo.com/?q=%s" },
  youtube: { name: "YouTube", url: "https://www.youtube.com/results?search_query=%s" }
};

// Inicializar Select de Buscadores
function initEngineSelect() {
  if (!searchEngine) return;
  searchEngine.innerHTML = "";
  Object.keys(SEARCH_ENGINES).forEach((key) => {
    const opt = document.createElement("option");
    opt.value = SEARCH_ENGINES[key].url;
    opt.textContent = SEARCH_ENGINES[key].name;
    searchEngine.appendChild(opt);
  });
}
initEngineSelect();

// Formato de Timestamp para Logs
function ts() { 
  return new Date().toISOString().slice(11, 19); 
}

// Sistema de Logging en Terminal
function log(level, msg, detail) {
  if (!logEl) return;
  const line = document.createElement("div");
  line.style.marginBottom = "4px";
  
  let prefix = "[INFO]";
  if (level === "ok") prefix = "[OK]";
  if (level === "err") prefix = "[ERROR]";
  
  let text = `[${ts()}] ${prefix} ${String(msg || "")}`;
  if (detail) text += `\n  ↳ ${String(detail)}`;
  
  line.textContent = text;
  logEl.appendChild(line);
  logEl.scrollTop = logEl.scrollHeight;
}

// Configuración Visual de Indicadores (Pills)
function setPill(el, text, state) {
  if (!el) return;
  el.textContent = text;
  el.className = "pill";
  if (state === "ok") el.classList.add("pill-mint");
  else if (state === "warn") el.classList.add("pill-amber");
  else if (state === "err") el.classList.add("pill-rose");
  else el.classList.add("pill-blue");
}

// Limpieza de Log
if (btnClear) {
  btnClear.onclick = function () {
    logEl.textContent = "";
    log("info", "Log del sistema limpiado.");
  };
}

// Chequeo de Salud del Servidor
if (btnHealth) {
  btnHealth.onclick = async function () {
    log("info", "Verificando salud del servidor backend...");
    try {
      const res = await fetch("/api/music/tracks");
      if (res.ok) {
        log("ok", "Servidor respondió adecuadamente (HTTP 200)");
      } else {
        log("err", "El servidor devolvió un error:", res.status);
      }
    } catch (err) {
      log("err", "Fallo al conectar con el backend", err.message);
    }
  };
}

// Control de la Vista de Música (Full Screen Overlay)
function openMusic() {
  musicView.classList.remove("hidden");
  log("info", "Servidor de Música abierto en pantalla completa.");
  loadTracks();
}

function closeMusic() {
  musicView.classList.add("hidden");
  log("info", "Volviendo a la vista de Terminal.");
}

if (btnMusicToggle) btnMusicToggle.onclick = openMusic;
if (btnCloseMusic) btnCloseMusic.onclick = closeMusic;

// Sub-Tabs (Reproductor vs Guía API)
if (tabBtnPlayer && tabBtnApi) {
  tabBtnPlayer.onclick = () => {
    tabBtnPlayer.classList.add("active");
    tabBtnApi.classList.remove("active");
    tabContentPlayer.classList.remove("hidden");
    tabContentApi.classList.add("hidden");
  };

  tabBtnApi.onclick = () => {
    tabBtnApi.classList.add("active");
    tabBtnPlayer.classList.remove("active");
    tabContentApi.classList.remove("hidden");
    tabContentPlayer.classList.add("hidden");
  };
}

// Copiar Ejemplos de Código al Portapapeles
window.copyCode = function(elementId) {
  const el = document.getElementById(elementId);
  if (!el) return;
  navigator.clipboard.writeText(el.innerText).then(() => {
    log("ok", "Código copiado al portapapeles.");
  });
};

// Monitoreo en Tiempo Real del Scraper & Cola
async function checkScraperStatus() {
  try {
    const res = await fetch("/api/scraper/status");
    if (!res.ok) return;
    const data = await res.json();

    if (data.currentDownloading) {
      setPill(pillScraper, "Scraper: Descargando", "ok");
      scraperBadge.textContent = "DESCARGANDO";
      scraperBadge.className = "badge active";
      scraperDownloadingText.textContent = data.currentDownloading.title || data.currentDownloading.targetUrl;
    } else {
      setPill(pillScraper, "Scraper: Standby", "warn");
      scraperBadge.textContent = "STANDBY";
      scraperBadge.className = "badge";
      scraperDownloadingText.textContent = "Ninguna descarga activa";
    }

    queueCount.textContent = data.queueLength || 0;
    queueList.innerHTML = "";
    if (data.queue && data.queue.length > 0) {
      data.queue.forEach((item) => {
        const li = document.createElement("li");
        li.textContent = item.query || item.targetUrl;
        queueList.appendChild(li);
      });
    } else {
      queueList.innerHTML = '<li class="empty-msg">Cola vacía</li>';
    }
  } catch (e) {
    setPill(pillScraper, "Scraper: Inaccesible", "err");
  }
}
setInterval(checkScraperStatus, 3000);

// Encolar Canción o Búsqueda
if (musicAddForm) {
  musicAddForm.onsubmit = async function (e) {
    e.preventDefault();
    const val = musicAddInput.value.trim();
    if (!val) return;

    log("info", "Petición de descarga enviada:", val);
    musicAddInput.value = "";

    try {
      const res = await fetch("/api/scraper/add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: val })
      });
      const data = await res.json();
      if (data.ok) {
        log("ok", "Canción agregada a la cola con éxito", val);
        setTimeout(checkScraperStatus, 500);
      } else {
        log("err", "No se pudo encolar:", data.error);
      }
    } catch (err) {
      log("err", "Error al conectar con la API de descargas", err.message);
    }
  };
}

// Cargar Biblioteca desde Supabase
async function loadTracks() {
  try {
    const res = await fetch("/api/music/tracks");
    if (!res.ok) return;
    const data = await res.json();

    if (data.tracks && data.tracks.length > 0) {
      if (data.tracks.length === lastTrackCount) return;
      lastTrackCount = data.tracks.length;

      tracksList.innerHTML = "";
      data.tracks.forEach((track) => {
        const item = document.createElement("div");
        item.className = "track-item";
        item.onclick = () => playTrack(track);

        const img = document.createElement("img");
        img.src = track.cover_url || "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='40' height='40'><rect width='100%' height='100%' fill='%23e2e8f0'/></svg>";

        const info = document.createElement("div");
        info.className = "track-item-info";

        const title = document.createElement("div");
        title.className = "track-item-title";
        title.textContent = track.title;

        const artist = document.createElement("div");
        artist.className = "track-item-artist";
        artist.textContent = track.artist;

        info.appendChild(title);
        info.appendChild(artist);
        item.appendChild(img);
        item.appendChild(info);
        tracksList.appendChild(item);
      });
    } else {
      tracksList.innerHTML = '<p class="muted">No hay canciones guardadas aún.</p>';
    }
  } catch (e) {
    tracksList.innerHTML = '<p class="muted">Error al conectar con la biblioteca.</p>';
  }
}
setInterval(loadTracks, 5000);

// Reproductor y Renderizador de Letras
function playTrack(track) {
  playerTitle.textContent = track.title;
  playerArtist.textContent = track.artist;
  playerCover.src = track.cover_url || "";

  if (track.animated_cover_url) {
    playerAnimatedCover.src = track.animated_cover_url;
    playerAnimatedCover.classList.remove("hidden");
    playerCover.classList.add("hidden");
  } else {
    playerAnimatedCover.classList.add("hidden");
    playerCover.classList.remove("hidden");
  }

  musicAudioPlayer.src = track.audio_url;
  musicAudioPlayer.play();
  log("ok", `Reproduciendo: ${track.title} - ${track.artist}`);

  parseAndRenderLyrics(track.synced_lyrics || track.lyrics);
}

function parseAndRenderLyrics(lrcText) {
  lyricsContainer.innerHTML = "";
  currentSyncedLyrics = [];

  if (!lrcText) {
    lyricsContainer.innerHTML = '<p class="muted">No hay letras disponibles para esta pista.</p>';
    return;
  }

  if (!lrcText.includes("[")) {
    lyricsContainer.innerText = lrcText;
    return;
  }

  const lines = lrcText.split("\n");
  const regex = /\[(\d{2}):(\d{2})\.(\d{2,3})\](.*)/;

  lines.forEach((line) => {
    const match = line.match(regex);
    if (match) {
      const min = parseInt(match[1], 10);
      const sec = parseInt(match[2], 10);
      const time = min * 60 + sec;
      const text = match[4].trim();
      if (text) currentSyncedLyrics.push({ time, text });
    }
  });

  currentSyncedLyrics.forEach((item, idx) => {
    const div = document.createElement("div");
    div.className = "lyric-line";
    div.id = `lyric-line-${idx}`;
    div.textContent = item.text;
    lyricsContainer.appendChild(div);
  });
}

if (musicAudioPlayer) {
  musicAudioPlayer.ontimeupdate = function () {
    if (!currentSyncedLyrics.length) return;
    const currentTime = musicAudioPlayer.currentTime;

    for (let i = 0; i < currentSyncedLyrics.length; i++) {
      const item = currentSyncedLyrics[i];
      const nextItem = currentSyncedLyrics[i + 1];

      if (currentTime >= item.time && (!nextItem || currentTime < nextItem.time)) {
        document.querySelectorAll(".lyric-line").forEach((el) => el.classList.remove("active"));
        const activeLine = document.getElementById(`lyric-line-${i}`);
        if (activeLine) {
          activeLine.classList.add("active");
          activeLine.scrollIntoView({ behavior: "smooth", block: "center" });
        }
        break;
      }
    }
  };
}

// Resolve input to absolute URL or search
function resolveNavInput(input, template) {
  try { return new URL(input).toString(); } catch (e) {}
  try {
    const u = new URL("http://" + input);
    if (u.hostname.includes(".")) return u.toString();
  } catch (e) {}
  return String(template || "https://duckduckgo.com/?q=%s").replace("%s", encodeURIComponent(input));
}

function uvXorEncode(url) {
  let out = "";
  for (let i = 0; i < url.length; i++) {
    out += i % 2 ? String.fromCharCode(url.charCodeAt(i) ^ 2) : url[i];
  }
  return encodeURIComponent(out);
}

async function openViaProxy(targetUrl) {
  iframesContainer.innerHTML = "";
  iframesContainer.classList.add("active");
  if (homeView) homeView.classList.add("hidden");

  const iframe = document.createElement("iframe");
  iframe.style.cssText = "width:100%;height:100%;border:0;background:#0b0c0f;";
  iframe.setAttribute("allow", "fullscreen; accelerometer; gyroscope; autoplay; clipboard-read; clipboard-write; encrypted-media");
  iframesContainer.appendChild(iframe);

  // Prefer Scramjet controller when available
  try {
    if (typeof $scramjetLoadController === "function") {
      const { ScramjetController } = $scramjetLoadController();
      const sj = new ScramjetController({
        prefix: "/scramjet/",
        files: {
          wasm: "/scram/scramjet.wasm.wasm",
          all: "/scram/scramjet.all.js",
          sync: "/scram/scramjet.sync.js"
        }
      });
      await sj.init();
      iframe.src = sj.encodeUrl(targetUrl);
      log("ok", "Scramjet navigation:", targetUrl);
      return;
    }
  } catch (err) {
    log("err", "Scramjet failed, falling back:", err && err.message);
  }

  // UV fallback
  try {
    iframe.src = "/service/" + uvXorEncode(targetUrl);
    log("ok", "Ultraviolet navigation:", targetUrl);
    return;
  } catch (err) {
    log("err", "UV failed:", err && err.message);
  }

  // Last resort: stream API
  iframe.src = "/api/stream?url=" + encodeURIComponent(targetUrl);
  log("info", "Stream API fallback:", targetUrl);
}

// Búsqueda / Proxy Submit
if (form) {
  form.onsubmit = function (e) {
    e.preventDefault();
    const query = address.value.trim();
    if (!query) return;

    const engineEl = document.getElementById("sj-search-engine");
    const template = (engineEl && engineEl.value) || "https://www.google.com/search?q=%s";
    const target = resolveNavInput(query, template);

    log("info", "Ejecutando comando/URL vía proxy:", target);
    openViaProxy(target);
  };
}

if (btnProxyTest) {
  btnProxyTest.onclick = function () {
    log("info", "Ejecutando prueba de conexión proxy...");
    setTimeout(() => {
      log("ok", "Proxy respondiendo correctamente a través del transporte Wisp.");
    }, 800);
  };
}

// Inicialización de la Aplicación
setPill(pillApi, "API: Lista", "ok");
setPill(pillSw, "SW: Activo", "ok");
setPill(pillTransport, "Transport: Wisp", "ok");
log("info", "Hoshi Terminal inicializado con estilo pastel.");
checkScraperStatus();
