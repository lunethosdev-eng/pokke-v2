# Mantener el backend siempre despierto (Render free)

Render **apagará** el servicio free ~15 min sin tráfico. Opciones:

## A) GitHub Actions (incluido)

1. Sube este repo a GitHub.
2. Activa **Actions** en el repo.
3. El workflow `.github/workflows/keep-alive.yml` hace ping cada **10 minutos** a:
   `https://backend-1-k2na.onrender.com/api/health`
4. Opcional: en el repo → Settings → Secrets and variables → Actions → **Variables**:
   - `BACKEND_HEALTH_URL` = tu URL de health si cambia.

## B) UptimeRobot (gratis, sin GitHub)

1. https://uptimerobot.com → Add New Monitor
2. Type: HTTP(s)
3. URL: `https://backend-1-k2na.onrender.com/api/health`
4. Interval: **5 minutes**

## C) Plan de pago en Render

Instance sin spin-down = always on real.

## Scramjet completo (JS / CSS / fetch / WS)

Tu backend **ya** usa el paquete `@mercuryworkshop/scramjet` + Wisp + libcurl:

- Ruta completa: `/?go=URL&embed=1`
- API solo HTML: `/api/proxy?url=`

El ZIP `scramjet-main` es el **código fuente** del monorepo para **compilar** Scramjet.
**No** hay que copiarlo dentro de Hoshi. Render instala Scramjet con `pnpm/npm install` desde `package.json`.

Prism OS debe usar siempre Scramjet (`/?go=`), no solo `/api/proxy`.
