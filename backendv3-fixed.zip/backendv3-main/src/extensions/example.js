// Optional extension example.
// Extensions are loaded automatically by the backend. A future Sekai OS app can
// add backend capabilities without editing src/index.js: create another .js file here.
export default async function register({ fastify, sendJson }) {
  fastify.get('/api/extensions/example', async (_req, reply) =>
    sendJson(reply, { ok: true, extension: 'example', version: 1 })
  );
}
