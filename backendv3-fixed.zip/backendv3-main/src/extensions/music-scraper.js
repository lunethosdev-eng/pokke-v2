import { createClient } from "@supabase/supabase-js";
import ytDlp from "yt-dlp-exec";
import ffmpegStatic from "ffmpeg-static";
import fs from "node:fs";
import path from "node:path";
import os from "node:os";

// Resolver correctamente el ejecutable de FFmpeg en ESM (type: module)
const ffmpegExecutable = typeof ffmpegStatic === "string" ? ffmpegStatic : (ffmpegStatic?.default || ffmpegStatic);

// Dar permisos de ejecución en entornos Linux (Render)
if (ffmpegExecutable && fs.existsSync(ffmpegExecutable)) {
  try {
    fs.chmodSync(ffmpegExecutable, 0o755);
  } catch (e) {
    console.log("[FFmpeg Perms Warning]:", e.message);
  }
}

// Configuración de Supabase
const SUPABASE_URL = "https://ajbmpgnzkgtcmulocftd.supabase.co";
const SUPABASE_SERVICE_ROLE = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFqYm1wZ256a2d0Y211bG9jZnRkIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc5MDM0NTYyOSwiZXhwIjoyMTA1OTIxNjI5fQ.JIw6EUefVcnQ7-P8-lRg__bAhEJvjcQYGFfaXpk9Vik";

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE);

// Cookies de sesión de YouTube
const YT_COOKIES_RAW = `__Secure-YNID=22.YT=ACR7e-aD_F45EV8y2-tVMv-1XZDtZSNqBn6cA1uTE4Qm1IxedK7UItwm-Xy7NQWfWSvBfTA2js1C9aXo2ODeTj2U8s7ALAiMEW7-BPkUnTQDScbY1A689UWOyL7oVCm5VlbAC8QRz8FUGurpTE3_DBmkZ9JPZ5pV8UKp8giIggE-q804k2tPr0ml9QIqqAio6XI7XyRyoaQZdT3ozB5Cc-dMrtWhDl1KhdQpCv2iZa9PXOtRS3faF4wgXSZ5piZY3y5wqyECSA-C6XAhj73W4QRAy5lzdFS-RS3AfAy1N-3uTeCWUaRQfF0ujrI_ijkcfkZay4WyDdFqoc2bmUYGbA;VISITOR_INFO1_LIVE=BxKm35EsG5Q;VISITOR_PRIVACY_METADATA=CgJTVhIEGgAgLw%3D%3D;PREF=f4=4000000&f6=40000000&tz=America.El_Salvador;CONSISTENCY=AJDB8J-zS4s-iLt4ka5_7BKpLErl6VkMoWKcYUgaksgi00PD0WBz47ToGVLYkPyHKc_kvLhdl3ie2esS50vmPlxdPX2_kt7f4TSOrubnORaHENPnza29e44nD6wisyPJXCX3HJFcegb3J01FM2fmDFCx;NID=CvkBCAESqwEBp2sxrsiVt5wB2VptaLWMUdwzHR2Zka3YvFwlEg5h7-xYReCGtnGwjlsUqMFqWKJUWEvNeTDU6L6GkVFbwYQUV2bjumnUuMwHdhcg92P4a-2A3X0Wf44_HghBhGotVx6uhPEwcHx0JpK3BD5cbCdmFS58yIoTJ8nteAuuMiMSVMSJnFMoXeeXKSlmtzAD57ETwbv6Uke67xkBMzIT4udO7zfU886m2mZXAjsoATJFAQ4r3hENiM9hpFiCtR3ZfxOB2sAwDY-btdFkK16U7CNZKoqbRNjP2RUVZW-rSwwqOahroGjrWUQSTOKGNGkATCTlKQYF;GPS=1;YSC=EKkyMFl9OpM`;

/**
 * Genera el archivo cookies.txt en formato Netscape compatible con yt-dlp
 */
function getCookiesFilePath() {
  const cookiePath = path.join(os.tmpdir(), "yt_cookies.txt");
  const lines = [
    "# Netscape HTTP Cookie File",
    "# https://curl.haxx.se/rfc/cookie_spec.html",
    "# This is a generated file! Do not edit.",
    ""
  ];

  const pairs = YT_COOKIES_RAW.split(";");
  for (const pair of pairs) {
    const trimmed = pair.trim();
    if (!trimmed) continue;
    const eqIdx = trimmed.indexOf("=");
    if (eqIdx === -1) continue;
    const name = trimmed.substring(0, eqIdx).trim();
    const value = trimmed.substring(eqIdx + 1).trim();
    lines.push(`.youtube.com\tTRUE\t/\tTRUE\t2147483647\t${name}\t${value}`);
  }

  fs.writeFileSync(cookiePath, lines.join("\n"), "utf8");
  return cookiePath;
}

// Cola de procesamientos en memoria
const scraperQueue = [];
let currentDownloading = null;

/**
 * Busca letras mediante la API LRCLIB
 */
async function fetchLyrics(artist, title) {
  try {
    const cleanTitle = title.replace(/\(.*\)|\[.*\]/g, "").trim();
    const url = `https://lrclib.net/api/get?artist_name=${encodeURIComponent(artist)}&track_name=${encodeURIComponent(cleanTitle)}`;
    const res = await fetch(url);
    if (!res.ok) return null;
    const data = await res.json();
    return data.syncedLyrics || data.plainLyrics || null;
  } catch (err) {
    console.log("[Lyrics Warning]: No se encontraron letras para", title);
    return null;
  }
}

/**
 * Consulta la API de Apple Music para metadatos y portadas HD (1000x1000)
 */
async function fetchAppleMusicMeta(query) {
  try {
    const cleanQuery = query.replace(/ official video| official audio| lyric video| video oficial/gi, "");
    const res = await fetch(`https://itunes.apple.com/search?term=${encodeURIComponent(cleanQuery)}&entity=song&limit=1`);
    if (!res.ok) return null;
    const data = await res.json();
    if (!data.results || data.results.length === 0) return null;

    const track = data.results[0];
    const coverHq = track.artworkUrl100 ? track.artworkUrl100.replace("100x100bb", "1000x1000bb") : null;

    return {
      title: track.trackName,
      artist: track.artistName,
      album: track.collectionName,
      coverUrl: coverHq,
      previewUrl: track.previewUrl
    };
  } catch (err) {
    console.log("[Apple Music Meta Warning]:", err.message);
    return null;
  }
}

export default async function ({ fastify, sendJson }) {

  async function processQueue() {
    if (currentDownloading || scraperQueue.length === 0) return;

    const item = scraperQueue[0];
    currentDownloading = { targetUrl: item.query, title: item.query };

    const tmpDir = os.tmpdir();
    const fileId = Date.now().toString();
    const tmpOutputPath = path.join(tmpDir, `${fileId}.%(ext)s`);
    const expectedMp3Path = path.join(tmpDir, `${fileId}.mp3`);
    const cookiesFile = getCookiesFilePath();

    try {
      console.log(`[Scraper] Iniciando procesamiento de: "${item.query}"`);

      let downloadTarget = item.query;
      if (!downloadTarget.startsWith("http://") && !downloadTarget.startsWith("https://")) {
        downloadTarget = `ytsearch1:${item.query}`;
      }

      // 1. Extraer metadatos con yt-dlp usando cookies
      const metadata = await ytDlp(downloadTarget, {
        dumpJson: true,
        noWarnings: true,
        noCheckCertificates: true,
        cookies: cookiesFile,
        ffmpegLocation: ffmpegExecutable
      });

      const entry = metadata.entries ? metadata.entries[0] : metadata;
      let rawTitle = entry?.title || item.query;
      let rawArtist = entry?.uploader || entry?.artist || "Desconocido";
      let coverUrl = entry?.thumbnail || "";
      let albumName = entry?.album || "";

      // 2. Enriquecer metadatos con Apple Music
      const appleMeta = await fetchAppleMusicMeta(`${rawArtist} ${rawTitle}`);
      if (appleMeta) {
        if (appleMeta.coverUrl) coverUrl = appleMeta.coverUrl;
        if (appleMeta.album) albumName = appleMeta.album;
        if (appleMeta.title) rawTitle = appleMeta.title;
        if (appleMeta.artist) rawArtist = appleMeta.artist;
      }

      // 3. Obtener Letras
      const lyrics = await fetchLyrics(rawArtist, rawTitle);

      currentDownloading.title = `${rawArtist} - ${rawTitle}`;

      // 4. Descargar y Convertir Audio
      console.log(`[Scraper] Descargando audio con FFmpeg en: ${ffmpegExecutable}`);
      await ytDlp(downloadTarget, {
        extractAudio: true,
        audioFormat: "mp3",
        audioQuality: 0,
        output: tmpOutputPath,
        noPlaylist: true,
        noCheckCertificates: true,
        cookies: cookiesFile,
        ffmpegLocation: ffmpegExecutable
      });

      // 5. Localizar el archivo descargado (Fallback si ffmpeg no generó el .mp3 explícito)
      let finalAudioPath = expectedMp3Path;
      let mimeType = "audio/mpeg";

      if (!fs.existsSync(expectedMp3Path)) {
        console.warn(`[Scraper Warning]: No se encontró .mp3 directo. Buscando alternativas en ${tmpDir}...`);
        const files = fs.readdirSync(tmpDir);
        const downloadedFile = files.find(f => f.startsWith(fileId) && !f.endsWith('.txt'));

        if (downloadedFile) {
          finalAudioPath = path.join(tmpDir, downloadedFile);
          const ext = path.extname(downloadedFile).toLowerCase();
          if (ext === '.m4a') mimeType = 'audio/mp4';
          else if (ext === '.webm') mimeType = 'audio/webm';
          else if (ext === '.ogg') mimeType = 'audio/ogg';
          console.log(`[Scraper Fallback]: Usando archivo encontrado: ${downloadedFile} (${mimeType})`);
        } else {
          throw new Error(`Error fatal: yt-dlp no generó ningún archivo de audio para ID ${fileId}`);
        }
      }

      // 6. Subida de Audio al Bucket "music-files" en Supabase
      console.log(`[Scraper] Subiendo archivo de audio a Supabase Storage...`);
      const fileBuffer = fs.readFileSync(finalAudioPath);
      const cleanArtist = rawArtist.replace(/[^a-zA-Z0-9]/g, "_");
      const fileExt = path.extname(finalAudioPath) || ".mp3";
      const audioStoragePath = `${cleanArtist}/${fileId}${fileExt}`;

      const { error: audioUploadErr } = await supabase.storage
        .from("music-files")
        .upload(audioStoragePath, fileBuffer, {
          contentType: mimeType,
          upsert: true
        });

      if (audioUploadErr) {
        console.error("[Supabase Storage Error - Audio]:", audioUploadErr);
        throw audioUploadErr;
      }

      const { data: publicAudioData } = supabase.storage
        .from("music-files")
        .getPublicUrl(audioStoragePath);

      // 7. Subida opcional de Portada al Bucket "covers"
      let finalCoverUrl = coverUrl;
      if (coverUrl && coverUrl.startsWith("http")) {
        try {
          const coverRes = await fetch(coverUrl);
          if (coverRes.ok) {
            const coverBuffer = Buffer.from(await coverRes.arrayBuffer());
            const coverStoragePath = `${cleanArtist}/${fileId}.jpg`;

            const { error: coverUploadErr } = await supabase.storage
              .from("covers")
              .upload(coverStoragePath, coverBuffer, {
                contentType: "image/jpeg",
                upsert: true
              });

            if (!coverUploadErr) {
              const { data: publicCoverData } = supabase.storage
                .from("covers")
                .getPublicUrl(coverStoragePath);
              finalCoverUrl = publicCoverData.publicUrl;
            }
          }
        } catch (cErr) {
          console.log("[Cover Upload Warning]: Se usará URL externa para la imagen.");
        }
      }

      // 8. Insertar Registro en la Tabla "tracks"
      console.log(`[Scraper] Registrando canción en Supabase DB...`);
      const { data: insertedTrack, error: dbErr } = await supabase
        .from("tracks")
        .insert([{
          title: rawTitle,
          artist: rawArtist,
          album: albumName,
          audio_url: publicAudioData.publicUrl,
          cover_url: finalCoverUrl,
          lyrics: lyrics,
          provider: entry?.extractor || "youtube",
          source_url: entry?.webpage_url || item.query
        }])
        .select();

      if (dbErr) {
        console.error("[Supabase DB Insert Error]:", dbErr);
        throw dbErr;
      }

      console.log(`[Scraper Éxito]: Registrado correctamente "${rawTitle}"`, insertedTrack);

    } catch (err) {
      console.error("[Scraper Error Principal]:", err.message || err);
    } finally {
      // Limpieza de archivos temporales
      try {
        const files = fs.readdirSync(tmpDir);
        for (const f of files) {
          if (f.startsWith(fileId)) {
            fs.unlinkSync(path.join(tmpDir, f));
          }
        }
      } catch (e) {}

      scraperQueue.shift();
      currentDownloading = null;
      processQueue();
    }
  }

  // Rutas API
  fastify.get("/api/scraper/status", async (req, reply) => {
    return sendJson(reply, {
      isNightWindow: true,
      currentDownloading,
      queueLength: scraperQueue.length,
      queue: scraperQueue
    });
  });

  fastify.post("/api/scraper/add", async (req, reply) => {
    const { query } = req.body || {};
    if (!query) return sendJson(reply, { error: "Proporciona un término de búsqueda o enlace" }, 400);

    scraperQueue.push({ id: Date.now(), query, targetUrl: query });
    processQueue();

    return sendJson(reply, { ok: true, message: "Añadido a la cola correctamente" });
  });

  fastify.get("/api/music/tracks", async (req, reply) => {
    try {
      const { data, error } = await supabase
        .from("tracks")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      return sendJson(reply, { ok: true, tracks: data });
    } catch (error) {
      return sendJson(reply, { error: error.message }, 500);
    }
  });

  fastify.get("/api/music/apple-metadata", async (req, reply) => {
    const { query } = req.query || {};
    if (!query) return sendJson(reply, { error: "Falta el parámetro query" }, 400);

    const meta = await fetchAppleMusicMeta(query);
    if (!meta) return sendJson(reply, { error: "No encontrado en Apple Music" }, 404);

    return sendJson(reply, { ok: true, ...meta });
  });
}
