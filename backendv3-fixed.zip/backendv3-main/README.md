# Sekai OS Backend — Render

Backend-only service for Sekai OS. The complete OS/UI stays on Netlify. Render provides the proxy transport and generic backend APIs.

## Included
- Scramjet transport and vendor assets
- Ultraviolet package integration (UV is legacy/superseded by Scramjet; kept as a compatibility engine)
- Bare Server + Wisp
- Per-session cookie jar for the generic HTTP proxy
- Redirect validation and private/local destination blocking
- Configurable CORS for the Netlify frontend
- `/api/health`, `/api/session`, `/api/transports`
- `/api/proxy?url=...` and `/api/stream?url=...`
- Automatic backend extension loading from `src/extensions/*.js`

## Important configuration
Set these Render environment variables:

`CORS_ORIGINS` = your Netlify URL(s), comma-separated.

`ALLOW_ALL_PROXY=false` by default. With this setting, `PROXY_ALLOWLIST` must contain the domains the proxy is allowed to reach. This is intentionally restrictive for a public deployment.

If you have a legitimate reason to use a general-purpose proxy, review Render's acceptable-use rules and your traffic pattern before enabling it.

## Adding future Sekai OS features
Frontend-only apps do not require backend changes. They live in your Sekai OS project on Netlify.

For a backend-required feature, add an extension module under `src/extensions/`. The server automatically imports `.js` extension files at startup. This keeps `src/index.js` as the stable core instead of turning it into one giant file.

For durable app/user data, use an external database/storage adapter rather than relying on Render's local filesystem.

## Deploy
Connect this folder/repository to Render as a Node web service. Render can also use `render.yaml`.
