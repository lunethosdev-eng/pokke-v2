import { createServer } from "node:http";
import { fileURLToPath } from "url";
import { hostname } from "node:os";
import { server as wisp, logging } from "@mercuryworkshop/wisp-js/server";
import Fastify from "fastify";
import fastifyStatic from "@fastify/static";

import { scramjetPath } from "@mercuryworkshop/scramjet/path";
import { libcurlPath } from "@mercuryworkshop/libcurl-transport";
import { baremuxPath } from "@mercuryworkshop/bare-mux/node";
import { epoxyPath } from "@mercuryworkshop/epoxy-transport";
import { bareModulePath } from "@mercuryworkshop/bare-as-module3";
import { createBareServer } from "@tomphttp/bare-server-node";
import { randomUUID } from "node:crypto";
import { readdir } from "node:fs/promises";
import { join as pathJoin } from "node:path";

const publicPath = fileURLToPath(new URL("../public/", import.meta.url));

logging.set_level(logging.NONE);
Object.assign(wisp.options, {
  allow_udp_streams: false,
  hostname_blacklist: [/example\.com/],
  dns_servers: ["1.1.1.3", "1.0.0.3"],
});


// ---------- HOSHI proxy policy / session cookies ----------
const ALLOW_ALL_PROXY = process.env.ALLOW_ALL_PROXY !== "false"; // default OPEN — any page allowed
const ALLOWLIST = String(process.env.PROXY_ALLOWLIST || "")
  .split(",")
  .map((x) => x.trim().toLowerCase())
  .filter(Boolean);
const MAX_BODY_BYTES = Number(process.env.PROXY_MAX_BODY_BYTES || 25 * 1024 * 1024);
const REQUEST_TIMEOUT_MS = Number(process.env.PROXY_TIMEOUT_MS || 30000);
const sessions = new Map();
const SESSION_TTL_MS = 12 * 60 * 60 * 1000;
setInterval(() => { for (const [id, s] of sessions) if (Date.now() - s.touched > SESSION_TTL_MS) sessions.delete(id); }, 60 * 60 * 1000).unref();
const HOP_BY_HOP = new Set([
  "connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
  "te", "trailer", "transfer-encoding", "upgrade", "host", "content-length"
]);

if (ALLOWLIST.length && !ALLOW_ALL_PROXY) {
  wisp.options.hostname_whitelist = ALLOWLIST.map((rule) => {
    const escaped = rule.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    return new RegExp(`(^|\\.)${escaped}$`, "i");
  });
}
wisp.options.hostname_blacklist = [
  /^(localhost|.*\.localhost)$/i,
  /^(127\.|10\.|192\.168\.)/,
  /^(169\.254\.)/,
  /^\[?(::1|fc00:|fe80:)/i,
];

function allowedHost(hostname) {
  const h = hostname.toLowerCase().replace(/\.$/, "");
  // OPEN proxy: allow any public host unless ALLOW_ALL_PROXY=false and allowlist set
  if (ALLOW_ALL_PROXY) return true;
  if (!ALLOWLIST.length) return true; // empty allowlist = allow all
  return ALLOWLIST.some((rule) => h === rule || h.endsWith("." + rule));
}

function validateTarget(raw) {
  let u;
  try { u = new URL(String(raw || "")); } catch { throw Object.assign(new Error("URL invalida"), { code: "INVALID_URL" }); }
  if (!/^https?:$/.test(u.protocol)) throw Object.assign(new Error("Solo http/https"), { code: "BAD_PROTOCOL" });
  if (!allowedHost(u.hostname)) throw Object.assign(new Error("Destino no autorizado por PROXY_ALLOWLIST"), { code: "DEST_NOT_ALLOWED" });
  return u;
}

function parseBrowserCookieHeader(value) {
  const out = new Map();
  for (const part of String(value || "").split(";")) {
    const eq = part.indexOf("=");
    if (eq <= 0) continue;
    const name = part.slice(0, eq).trim();
    const val = part.slice(eq + 1).trim();
    if (name) out.set(name, val);
  }
  return out;
}

function getSession(req, reply) {
  let id = String(req.headers["x-hoshi-session"] || "").trim();
  if (!/^[a-f0-9-]{20,80}$/i.test(id)) {
    const parsed = parseBrowserCookieHeader(req.headers.cookie);
    id = String(parsed.get("hoshi_session") || "").trim();
  }
  if (!id || !sessions.has(id)) {
    id = randomUUID();
    sessions.set(id, { cookies: new Map(), created: Date.now(), touched: Date.now() });
    reply.header("Set-Cookie", `hoshi_session=${id}; Path=/; HttpOnly; SameSite=Lax; Max-Age=43200`);
  }
  const s = sessions.get(id); s.touched = Date.now();
  return { id, state: s };
}

function defaultCookiePath(pathname) {
  const path = String(pathname || "/");
  if (!path.startsWith("/") || path === "/") return "/";
  const i = path.lastIndexOf("/");
  return i <= 0 ? "/" : path.slice(0, i);
}

function storeSetCookies(state, url, headers) {
  const list = typeof headers.getSetCookie === "function"
    ? headers.getSetCookie()
    : (headers.get("set-cookie") ? [headers.get("set-cookie")] : []);
  for (const line of list) {
    const first = line.split(";", 1)[0];
    const eq = first.indexOf("=");
    if (eq < 1) continue;
    const name = first.slice(0, eq).trim();
    const value = first.slice(eq + 1).trim();
    const parts = line.split(";").slice(1).map((x) => x.trim());
    let domain = url.hostname.toLowerCase();
    let hostOnly = true;
    let path = defaultCookiePath(url.pathname);
    let maxAge = null;
    let expiresAt = null;
    let secure = false;
    let sameSite = null;
    let expired = false;
    for (const part of parts) {
      const eq2 = part.indexOf("=");
      const key = (eq2 >= 0 ? part.slice(0, eq2) : part).trim().toLowerCase();
      const v = eq2 >= 0 ? part.slice(eq2 + 1).trim() : "";
      if (key === "domain" && v) { domain = v.replace(/^\./, "").toLowerCase(); hostOnly = false; }
      else if (key === "path" && v.startsWith("/")) path = v;
      else if (key === "max-age" && v) maxAge = Number(v);
      else if (key === "expires" && v) { const t = Date.parse(v); if (Number.isFinite(t)) expiresAt = t; }
      else if (key === "secure") secure = true;
      else if (key === "samesite") sameSite = v.toLowerCase();
    }
    if (maxAge != null && Number.isFinite(maxAge)) {
      if (maxAge <= 0) expired = true;
      else expiresAt = Date.now() + maxAge * 1000;
    }
    if (expiresAt != null && expiresAt <= Date.now()) expired = true;
    // Never accept a Domain cookie for an unrelated host.
    if (!hostOnly && !(url.hostname === domain || url.hostname.endsWith("." + domain))) continue;
    const key = `${domain}|${path}|${name}`;
    if (expired) state.cookies.delete(key);
    else state.cookies.set(key, { name, value, domain, path, hostOnly, secure, sameSite, expiresAt });
  }
}

function cookieHeader(state, url) {
  const out = [];
  const host = url.hostname.toLowerCase();
  const path = url.pathname || "/";
  for (const [key, c] of state.cookies) {
    if (c.expiresAt && c.expiresAt <= Date.now()) { state.cookies.delete(key); continue; }
    if (c.hostOnly ? host !== c.domain : !(host === c.domain || host.endsWith("." + c.domain))) continue;
    const pathMatch = path === c.path || path.startsWith(c.path.endsWith("/") ? c.path : c.path + "/");
    if (!pathMatch) continue;
    if (c.secure && url.protocol !== "https:") continue;
    out.push(`${c.name}=${c.value}`);
  }
  return out.join("; ");
}

function forwardRequestHeaders(req, state, target) {
  const out = {};
  for (const [k, v] of Object.entries(req.headers || {})) {
    const key = k.toLowerCase();
    if (HOP_BY_HOP.has(key) || key === "cookie" || key === "origin" || key === "referer") continue;
    if (key === "user-agent" || key === "accept" || key === "accept-language" || key === "content-type" || key === "authorization" || key === "range" || key === "if-none-match" || key === "if-modified-since" || key === "if-range" || key === "cache-control" || key === "accept-encoding" || key.startsWith("x-")) out[key] = v;
  }
  const jar = cookieHeader(state, target);
  if (jar) out.cookie = jar;
  out["user-agent"] ||= "Mozilla/5.0 HoshiProxy/2.4";
  out.accept ||= "*/*";
  return out;
}

function exposeUpstreamHeaders(reply, res) {
  const expose = [];
  for (const [k, v] of res.headers) {
    const key = k.toLowerCase();
    if (HOP_BY_HOP.has(key) || key === "set-cookie" || key === "content-security-policy" || key === "x-frame-options") continue;
    if (key === "content-length" || key === "content-range" || key === "accept-ranges" || key === "content-type" || key === "etag" || key === "last-modified" || key === "cache-control") reply.header(k, v);
  }
  expose.push("Content-Type", "Content-Length", "Content-Range", "Accept-Ranges", "ETag", "Last-Modified");
  reply.header("Access-Control-Expose-Headers", expose.join(","));
}

function rewriteManifest(text, baseUrl, sessionId) {
  return text.replace(/(^|\n)(\s*)([^#\r\n][^\r\n]*)/g, (m, a, ws, value) => {
    const raw = value.trim();
    if (!raw || raw.startsWith("http://") || raw.startsWith("https://") || raw.startsWith("data:")) return m;
    try {
      const abs = new URL(raw, baseUrl).href;
      return `${a}${ws}/api/stream?session=${encodeURIComponent(sessionId)}&url=${encodeURIComponent(abs)}`;
    } catch { return m; }
  });
}

async function fetchWithTimeout(url, options = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try { return await fetch(url, { ...options, signal: controller.signal, redirect: "manual" }); }
  finally { clearTimeout(timer); }
}

async function fetchFollowingRedirects(initial, options, state) {
  let current = new URL(initial.href);
  let method = options.method || "GET";
  let body = options.body;
  for (let hop = 0; hop < 6; hop++) {
    if (!allowedHost(current.hostname)) throw Object.assign(new Error("Redirect hacia destino no autorizado"), { code: "REDIRECT_NOT_ALLOWED" });
    const headers = { ...(options.headers || {}) };
    const jar = cookieHeader(state, current);
    if (jar) headers.cookie = jar; else delete headers.cookie;
    const response = await fetchWithTimeout(current.href, { ...options, method, body, headers });
    storeSetCookies(state, current, response.headers);
    if (![301, 302, 303, 307, 308].includes(response.status)) return { response, url: current };
    const location = response.headers.get("location");
    if (!location) return { response, url: current };
    const next = new URL(location, current);
    if ([301, 302, 303].includes(response.status)) { method = "GET"; body = undefined; }
    current = next;
  }
  throw Object.assign(new Error("Demasiadas redirecciones"), { code: "TOO_MANY_REDIRECTS" });
}

function pipeWebStream(body, res) {
  if (!body) { res.end(); return Promise.resolve(); }
  const reader = body.getReader();
  let closed = false;
  const close = () => { if (!closed) { closed = true; try { res.end(); } catch {} } };
  res.on("close", () => { try { reader.cancel(); } catch {} });
  return (async () => {
    try {
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        if (!res.write(Buffer.from(value))) await new Promise((resolve) => res.once("drain", resolve));
      }
    } finally { close(); }
  })();
}

const CORS_ORIGINS = String(process.env.CORS_ORIGINS || "*")
  .split(",").map((x) => x.trim()).filter(Boolean);
function applyCors(res, req) {
  const origin = req?.headers?.origin;
  if (CORS_ORIGINS.includes("*") || !origin || CORS_ORIGINS.includes(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin || "*");
  }
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,PUT,PATCH,DELETE,OPTIONS,HEAD");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type,Authorization,X-Hoshi-Session,Range");
  res.setHeader("Access-Control-Expose-Headers", "*");
  if (origin && CORS_ORIGINS.includes(origin)) res.setHeader("Vary", "Origin");
}

const fastify = Fastify({
  serverFactory: (handler) => {
    return createServer()
      .on("request", (req, res) => {
        const url = req.url || "";
        const isApi = url.startsWith("/api/");
        const isEmbed = /[?&]embed=1(?:&|$)/.test(url) || /[?&]prism=1(?:&|$)/.test(url);

        // Always allow Prism / Netlify to frame this backend
        applyCors(res, req);

        // Critical: do NOT send X-Frame-Options so Prism windows can embed us
        // (omit header entirely)

        if (isApi) {
          // API only
        } else if (isEmbed) {
          // Embedded in Prism OS — no COOP/COEP (they break cross-origin iframes)
          res.setHeader("Content-Security-Policy", "frame-ancestors *");
        } else {
          // Standalone terminal UI — keep isolation but still allow framing by Prism
          res.setHeader("Content-Security-Policy", "frame-ancestors *");
          // COEP optional; skip so game iframes inside Scramjet work more often
        }
        if (bareServer && bareServer.shouldRoute(req)) {
          bareServer.routeRequest(req, res);
          return;
        }
        handler(req, res);
      })
      .on("upgrade", (req, socket, head) => {
        const raw = req.url || "/";
        if (raw === "/wisp/" || raw.startsWith("/wisp/?")) {
          req.url = raw.replace(/^\/wisp/, "") || "/wisp/";
          wisp.routeRequest(req, socket, head);
          return;
        }
        // Legacy wsproxy-compatible mode: /wsproxy/<host>:<port>
        if (raw.startsWith("/wsproxy/") && raw.length > 10) {
          req.url = raw.replace(/^\/wsproxy/, "");
          wisp.routeRequest(req, socket, head);
          return;
        }
        // Bare server WebSocket upgrades
        if (bareServer && bareServer.shouldRoute(req)) {
          bareServer.routeUpgrade(req, socket, head);
          return;
        }
        socket.end();
      });
  },
});

function stripFrameHeaders(reply) {
  // Allow embedding proxied HTML in Prism iframes
  try {
    reply.removeHeader("x-frame-options");
    reply.removeHeader("X-Frame-Options");
    reply.removeHeader("content-security-policy");
    reply.removeHeader("Content-Security-Policy");
  } catch (_) {}
  return reply
    .header("Access-Control-Allow-Origin", "*")
    .header("Content-Security-Policy", "frame-ancestors *")
    .header("X-Prism-Proxy", "1");
}

function sendError(reply, status, code, message, extra = {}) {
  return reply
    .header("Access-Control-Allow-Origin", "*")
    .header("Content-Type", "application/json; charset=utf-8")
    .code(status)
    .send({
      ok: false,
      error: true,
      code,
      message,
      ...extra,
    });
}

fastify.options("/api/proxy", async (req, reply) => {
  return reply
    .header("Access-Control-Allow-Origin", "*")
    .header("Access-Control-Allow-Methods", "GET,OPTIONS,HEAD")
    .header("Access-Control-Allow-Headers", "*")
    .code(204)
    .send();
});

fastify.get("/api/health", async (req, reply) => {
  return reply.header("Access-Control-Allow-Origin", "*").send({
    ok: true,
    service: "hoshi-backend",
    proxy: "/api/proxy?url=",
    stream: "/api/stream?url=",
    transports: "/api/transports",
    allowlistEnabled: !ALLOW_ALL_PROXY && ALLOWLIST.length > 0,
    ytAudio: "/api/yt-audio?id=VIDEO_ID",
    ytStream: "/api/yt-stream?id=VIDEO_ID",
    time: new Date().toISOString(),
  });
});

/* ===================== YOUTUBE AUDIO ===================== */
const YT_PIPED = [
  "https://api.piped.private.coffee",
  "https://pipedapi.kavin.rocks",
  "https://pipedapi.leptons.xyz",
  "https://pipedapi.adminforge.de",
  "https://pipedapi.ducks.party",
  "https://pipedapi.reallyaweso.me",
  "https://pipedapi-libre.kavin.rocks",
  "https://pipedapi.drgns.space",
  "https://pipedapi.syncpundit.io",
  "https://pipedapi.orangenet.cc",
];

const YT_INVIDIOUS = [
  "https://inv.nadeko.net",
  "https://yewtu.be",
  "https://invidious.nerdvpn.de",
  "https://invidious.privacyredirect.com",
  "https://vid.puffyan.us",
];

const COBALT_APIS = [
  "https://api.cobalt.tools/",
  "https://cobalt-api.kwiatekm.lol/",
];

async function fetchJsonServer(url, ms) {
  if (!ms) ms = 9000;
  const ctrl = new AbortController();
  const t = setTimeout(function () {
    ctrl.abort();
  }, ms);
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        Accept: "application/json",
      },
    });
    if (!res.ok) throw new Error("HTTP " + res.status);
    return await res.json();
  } finally {
    clearTimeout(t);
  }
}

function pickFromPiped(data) {
  var streams = data.audioStreams || [];
  if (streams.length) {
    var sorted = streams.slice().sort(function (a, b) {
      return (b.bitrate || 0) - (a.bitrate || 0);
    });
    var best = null;
    for (var i = 0; i < sorted.length; i++) {
      var m = sorted[i].mimeType || "";
      if (/mp4|m4a/i.test(m)) {
        best = sorted[i];
        break;
      }
    }
    if (!best) best = sorted[0];
    if (best && best.url) {
      return {
        url: best.url,
        mime: best.mimeType || "audio/mp4",
        quality: best.quality || best.bitrate,
        kind: "audio",
      };
    }
  }

  var videos = data.videoStreams || [];
  var withAudio = videos.filter(function (v) {
    return v && v.url && v.videoOnly === false;
  });
  if (withAudio.length) {
    withAudio.sort(function (a, b) {
      var qa = parseInt(String(a.quality || "999"), 10) || 999;
      var qb = parseInt(String(b.quality || "999"), 10) || 999;
      return qa - qb;
    });
    var v = withAudio[0];
    return {
      url: v.url,
      mime: v.mimeType || "video/mp4",
      quality: v.quality || "mixed",
      kind: "video+audio",
    };
  }

  return null;
}

function pickFromInvidious(data) {
  var formats = [].concat(data.adaptiveFormats || [], data.formatStreams || []);
  var audio = formats.filter(function (f) {
    return f && f.url && ((f.type && f.type.indexOf("audio") === 0) || (f.mimeType && /audio/i.test(f.mimeType)));
  });
  if (!audio.length) {
    // fallback: any progressive stream with audio
    audio = formats.filter(function (f) {
      return f && f.url && f.type && /video\/mp4/i.test(f.type) && !/video only/i.test(f.type);
    });
  }
  if (!audio.length) return null;
  audio.sort(function (a, b) {
    return (parseInt(b.bitrate || b.audioBitrate || 0, 10) || 0) -
           (parseInt(a.bitrate || a.audioBitrate || 0, 10) || 0);
  });
  var best = audio[0];
  return {
    url: best.url,
    mime: best.type || best.mimeType || "audio/mp4",
    quality: best.bitrate || best.audioBitrate || best.quality || "audio",
    kind: "audio",
  };
}

async function resolveViaCobalt(videoId) {
  var i, api, res, data, url;
  for (i = 0; i < COBALT_APIS.length; i++) {
    api = COBALT_APIS[i];
    try {
      res = await fetch(api, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          "User-Agent": "Mozilla/5.0 GojofyBackend/2.0",
        },
        body: JSON.stringify({
          url: "https://www.youtube.com/watch?v=" + videoId,
          downloadMode: "audio",
          audioFormat: "mp3",
          filenameStyle: "basic",
        }),
        signal: AbortSignal.timeout(12000),
      });
      if (!res.ok) continue;
      data = await res.json();
      // cobalt v7: status tunnel/redirect/picker
      url = data.url || data.audio || (data.tunnel && data.tunnel) || null;
      if (!url && data.status === "tunnel" && data.url) url = data.url;
      if (!url && data.status === "redirect" && data.url) url = data.url;
      if (url) {
        return {
          url: url,
          mime: "audio/mpeg",
          quality: "cobalt",
          kind: "audio",
          source: "cobalt",
          instance: api,
          title: data.filename || null,
        };
      }
    } catch (e) {}
  }
  return null;
}

async function resolveYoutubeAudio(videoId) {
  var i, base, data, picked, cobalt;

  // 1) Piped
  for (i = 0; i < YT_PIPED.length; i++) {
    base = YT_PIPED[i];
    try {
      data = await fetchJsonServer(base + "/streams/" + videoId, 7000);
      picked = pickFromPiped(data);
      if (picked && picked.url) {
        return {
          url: picked.url,
          mime: picked.mime,
          quality: picked.quality,
          kind: picked.kind,
          source: "piped",
          instance: base,
          title: data.title || null,
        };
      }
    } catch (e) {}
  }

  // 2) Invidious
  for (i = 0; i < YT_INVIDIOUS.length; i++) {
    base = YT_INVIDIOUS[i];
    try {
      data = await fetchJsonServer(base + "/api/v1/videos/" + videoId, 7000);
      picked = pickFromInvidious(data);
      if (picked && picked.url) {
        return {
          url: picked.url,
          mime: picked.mime,
          quality: picked.quality,
          kind: picked.kind,
          source: "invidious",
          instance: base,
          title: data.title || null,
        };
      }
    } catch (e) {}
  }

  // 3) Cobalt public APIs
  cobalt = await resolveViaCobalt(videoId);
  if (cobalt) return cobalt;

  return null;
}

fastify.options("/api/yt-audio", async function (req, reply) {
  return reply
    .header("Access-Control-Allow-Origin", "*")
    .header("Access-Control-Allow-Methods", "GET,OPTIONS,HEAD")
    .header("Access-Control-Allow-Headers", "*")
    .code(204)
    .send();
});

fastify.get("/api/yt-audio", async function (req, reply) {
  var id = String(req.query.id || "")
    .trim()
    .replace(/[^a-zA-Z0-9_-]/g, "");
  if (!id || id.length < 6) {
    return sendError(reply, 400, "MISSING_ID", "Falta ?id=VIDEO_ID");
  }

  var started = Date.now();
  try {
    var audio = await resolveYoutubeAudio(id);
    if (!audio) {
      return sendError(reply, 404, "NO_AUDIO", "No se encontro stream de audio", {
        id: id,
        ms: Date.now() - started,
      });
    }
    var host = (req.headers["x-forwarded-proto"] || "https") + "://" + (req.headers["x-forwarded-host"] || req.headers.host || "backend-1-k2na.onrender.com");
    return reply.header("Access-Control-Allow-Origin", "*").send({
      ok: true,
      id: id,
      url: audio.url,
      // URL lista para el player: pasa por este backend (CORS ok)
      streamUrl: host + "/api/yt-stream?id=" + id,
      mime: audio.mime,
      quality: audio.quality,
      kind: audio.kind,
      source: audio.source,
      instance: audio.instance,
      title: audio.title,
      ms: Date.now() - started,
    });
  } catch (err) {
    return sendError(reply, 502, "YT_AUDIO_FAIL", String(err.message || err), {
      id: id,
      ms: Date.now() - started,
    });
  }
});

// Stream proxy: el navegador reproduce desde TU dominio (sin CORS roto)
fastify.options("/api/yt-stream", async function (req, reply) {
  return reply
    .header("Access-Control-Allow-Origin", "*")
    .header("Access-Control-Allow-Methods", "GET,OPTIONS,HEAD")
    .header("Access-Control-Allow-Headers", "*")
    .header("Access-Control-Expose-Headers", "Content-Type,Content-Length,Accept-Ranges,Content-Range")
    .code(204)
    .send();
});

fastify.get("/api/yt-stream", async function (req, reply) {
  var id = String(req.query.id || "")
    .trim()
    .replace(/[^a-zA-Z0-9_-]/g, "");
  if (!id || id.length < 6) {
    return sendError(reply, 400, "MISSING_ID", "Falta ?id=VIDEO_ID");
  }

  try {
    var audio = await resolveYoutubeAudio(id);
    if (!audio || !audio.url) {
      return sendError(reply, 404, "NO_AUDIO", "No se encontro stream");
    }

    var headers = {
      "User-Agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
      Accept: "*/*",
    };
    if (req.headers.range) {
      headers.Range = req.headers.range;
    }

    var upstream = await fetch(audio.url, {
      headers: headers,
      redirect: "follow",
    });

    if (!upstream.ok && upstream.status !== 206) {
      return sendError(
        reply,
        502,
        "UPSTREAM_FAIL",
        "Stream upstream " + upstream.status
      );
    }

    var contentType =
      upstream.headers.get("content-type") || audio.mime || "video/mp4";

    // Stream pipe (no cargar todo en RAM)
    reply.hijack();
    var res = reply.raw;
    res.statusCode = upstream.status === 206 ? 206 : 200;
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader(
      "Access-Control-Expose-Headers",
      "Content-Type,Content-Length,Accept-Ranges,Content-Range"
    );
    res.setHeader("Content-Type", contentType);
    res.setHeader("Cache-Control", "no-store");
    res.setHeader("Accept-Ranges", "bytes");

    var contentRange = upstream.headers.get("content-range");
    if (contentRange) res.setHeader("Content-Range", contentRange);
    var contentLength = upstream.headers.get("content-length");
    if (contentLength) res.setHeader("Content-Length", contentLength);

    if (!upstream.body) {
      res.end();
      return;
    }

    var reader = upstream.body.getReader();
    function pump() {
      return reader.read().then(function (result) {
        if (result.done) {
          res.end();
          return;
        }
        res.write(Buffer.from(result.value));
        return pump();
      });
    }
    return pump().catch(function () {
      try {
        res.end();
      } catch (e) {}
    });
  } catch (err) {
    return sendError(reply, 502, "STREAM_FAIL", String(err.message || err));
  }
});
/* =================== END YOUTUBE AUDIO =================== */


const bareServer = createBareServer("/bare/", {
  connectionLimiter: { maxConnectionsPerIP: 2000, windowDuration: 60, blockDuration: 10 }
});

// Generic streaming/API proxy. Allowlist optional; open by default.
async function handleProxy(req, reply, streamMode = false) {
  let target;
  try { target = validateTarget(req.query.url); }
  catch (err) { return sendError(reply, err.code === "DEST_NOT_ALLOWED" ? 403 : 400, err.code || "INVALID_URL", err.message); }
  const { id, state } = getSession(req, reply);
  const method = String(req.method || "GET").toUpperCase();
  let body = undefined;
  if (!["GET", "HEAD"].includes(method)) {
    if (req.body && typeof req.body === "string") body = Buffer.from(req.body);
    else if (req.body != null) body = Buffer.from(JSON.stringify(req.body));
    if (body && body.length > MAX_BODY_BYTES) return sendError(reply, 413, "BODY_TOO_LARGE", "Request body demasiado grande");
  }
  const headers = forwardRequestHeaders(req, state, target);
  if (req.headers.range) headers.range = req.headers.range;
  if (req.headers["if-none-match"]) headers["if-none-match"] = req.headers["if-none-match"];
  if (req.headers["if-modified-since"]) headers["if-modified-since"] = req.headers["if-modified-since"];
  const fetched = await fetchFollowingRedirects(target, { method, headers, body }, state);
  const upstream = fetched.response;
  const finalTarget = fetched.url;
  exposeUpstreamHeaders(reply, upstream);
  reply.header("Access-Control-Allow-Origin", "*");
  reply.header("X-Hoshi-Session", id);
  reply.header("X-Hoshi-Upstream-Status", String(upstream.status));
  reply.header("X-Hoshi-Final-Url", upstream.url || finalTarget.href);
  reply.header("Cache-Control", "no-store");

  const type = upstream.headers.get("content-type") || "application/octet-stream";
  const isManifest = /application\/vnd\.apple\.mpegurl|application\/x-mpegurl|text\/vnd\.apple\.mpegurl/i.test(type) || /\.m3u8(?:$|\?)/i.test(target.pathname);
  if (!streamMode && isManifest && upstream.body) {
    const text = await upstream.text();
    return reply.code(upstream.status).type(type).send(rewriteManifest(text, new URL(upstream.url || finalTarget.href), id));
  }
  if (!upstream.body || method === "HEAD") return reply.code(upstream.status).send();
  reply.hijack();
  reply.raw.statusCode = upstream.status;
  reply.raw.setHeader("Content-Type", type);
  return pipeWebStream(upstream.body, reply.raw);
}

for (const method of ["GET", "POST", "PUT", "PATCH", "DELETE"]) {
  fastify.route({ method, url: "/api/proxy", handler: async (req, reply) => {
    if (method === "OPTIONS") return reply.code(204).header("Access-Control-Allow-Origin", "*").header("Access-Control-Allow-Methods", "GET,HEAD,POST,PUT,PATCH,DELETE,OPTIONS").header("Access-Control-Allow-Headers", "*").send();
    try { return await handleProxy(req, reply, false); }
    catch (err) { return sendError(reply, 502, "UPSTREAM_ERROR", String(err?.message || err)); }
  }});
}

fastify.route({ method: ["GET", "HEAD"], url: "/api/stream", handler: async (req, reply) => {
  try { return await handleProxy(req, reply, true); }
  catch (err) { return sendError(reply, 502, "STREAM_ERROR", String(err?.message || err)); }
}});

fastify.options("/api/session", async (_req, reply) => reply
  .header("Access-Control-Allow-Origin", "*")
  .header("Access-Control-Allow-Headers", "X-Hoshi-Session,Content-Type")
  .code(204).send());

fastify.get("/api/session", async (req, reply) => {
  const { id } = getSession(req, reply);
  return reply.header("Access-Control-Allow-Origin", "*").header("Cache-Control", "no-store").send({
    ok: true, session: id, expiresIn: SESSION_TTL_MS
  });
});

fastify.get("/api/capabilities", async (_req, reply) => reply.header("Access-Control-Allow-Origin", "*").send({
  ok: true,
  service: "sekai-os-backend",
  capabilities: [
    "proxy", "scramjet", "ultraviolet-compat", "wisp", "bare",
    "sessions", "cookies", "streaming", "extensions", "generic-api"
  ],
  frontend: "Netlify",
  backend: "Render"
}));

fastify.get("/api/transports", async (_req, reply) => reply.header("Access-Control-Allow-Origin", "*").send({
  ok: true,
  transports: ["libcurl-wisp", "epoxy-wisp", "wsproxy-legacy", "bare"],
  routes: { wisp: "/wisp/", wsproxy: "/wsproxy/<host>:<port>", bare: "/bare/", libcurl: "/libcurl/", epoxy: "/epoxy/", bareClient: "/baremod/" }
}));

// Ultraviolet compatibility assets. UV is legacy/superseded by Scramjet, but
// keeping its vendor directory makes the backend compatible with existing OS clients.
try {
  const { uvPath } = await import("@titaniumnetwork-dev/ultraviolet");
  fastify.register(fastifyStatic, { root: uvPath, prefix: "/uv/", decorateReply: false });
} catch (err) {
  console.warn("[Sekai] Ultraviolet assets unavailable:", err?.message || err);
}

fastify.register(fastifyStatic, {
  root: publicPath,
  decorateReply: true,
});

fastify.register(fastifyStatic, {
  root: scramjetPath,
  prefix: "/scram/",
  decorateReply: false,
});

fastify.register(fastifyStatic, {
  root: epoxyPath,
  prefix: "/epoxy/",
  decorateReply: false,
});

fastify.register(fastifyStatic, {
  root: bareModulePath,
  prefix: "/baremod/",
  decorateReply: false,
});

fastify.register(fastifyStatic, {
  root: libcurlPath,
  prefix: "/libcurl/",
  decorateReply: false,
});

fastify.register(fastifyStatic, {
  root: baremuxPath,
  prefix: "/baremux/",
  decorateReply: false,
});

fastify.setNotFoundHandler((req, reply) => {
  if (req.url && req.url.startsWith("/api/")) {
    return sendError(reply, 404, "API_NOT_FOUND", "Ruta API no existe", {
      path: req.url,
    });
  }
  return reply.code(404).type("text/html").sendFile("404.html");
});

async function loadExtensions() {
  const dir = pathJoin(publicPath, "../src/extensions");
  try {
    const entries = await readdir(dir, { withFileTypes: true });
    for (const entry of entries) {
      if (!entry.isFile() || !entry.name.endsWith(".js")) continue;
      const file = pathJoin(dir, entry.name);
      try {
        const mod = await import(new URL(`file://${file}`).href + `?v=${Date.now()}`);
        if (typeof mod.default === "function") {
          await mod.default({ fastify, sendJson: (reply, data, status = 200) => reply.code(status).header("Access-Control-Allow-Origin", "*").send(data) });
          console.log(`[Sekai] Extension loaded: ${entry.name}`);
        }
      } catch (err) {
        console.error(`[Sekai] Extension failed: ${entry.name}`, err);
      }
    }
  } catch (err) {
    if (err.code !== "ENOENT") console.warn("[Sekai] Extension directory error:", err);
  }
}

fastify.server.on("listening", () => {
  const address = fastify.server.address();
  console.log("Listening on:");
  console.log("\thttp://localhost:" + address.port);
  console.log("\thttp://" + hostname() + ":" + address.port);
  console.log("\tAPI health: /api/health");
  console.log("\tAPI proxy:  /api/proxy?url=");
  });

process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);

function shutdown() {
  console.log("SIGTERM signal received: closing HTTP server");
  fastify.close();
  process.exit(0);
}

let port = parseInt(process.env.PORT || "");
if (isNaN(port)) port = 8080;

await loadExtensions();

fastify.listen({
  port: port,
  host: "0.0.0.0",
});

// Soft keep-alive: while the process is running, touch health every 9 min.
// Does NOT prevent Render free spin-down when the process is already slept.
(function keepAliveSelfPing() {
  const port = process.env.PORT || 3000;
  const url = `http://127.0.0.1:${port}/api/health`;
  setInterval(() => {
    fetch(url).catch(() => {});
  }, 9 * 60 * 1000);
})();

